
# QueryErrorResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**header** | [**ErrorHeader**](ErrorHeader.md) |  |  [optional]
**error** | [**QueryErrorResponseBody**](QueryErrorResponseBody.md) |  |  [optional]



