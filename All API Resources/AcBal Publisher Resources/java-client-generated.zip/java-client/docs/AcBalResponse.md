
# AcBalResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**header** | [**QueryHeader**](QueryHeader.md) |  |  [optional]
**body** | [**AcBalResponseBody**](AcBalResponseBody.md) |  |  [optional]



