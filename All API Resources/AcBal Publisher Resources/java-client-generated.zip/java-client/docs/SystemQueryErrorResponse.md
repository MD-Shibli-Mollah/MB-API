
# SystemQueryErrorResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**header** | [**ErrorHeader**](ErrorHeader.md) |  |  [optional]
**error** | [**SystemQueryErrorResponseBody**](SystemQueryErrorResponseBody.md) |  |  [optional]



