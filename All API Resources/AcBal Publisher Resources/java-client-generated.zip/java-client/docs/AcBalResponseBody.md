
# AcBalResponseBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------



