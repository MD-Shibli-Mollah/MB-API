
# SystemQueryErrorResponseBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** | The identifier of the error message |  [optional]
**message** | **String** | The actual Transact error message caused by server |  [optional]
**type** | **String** | The identifier of error type: System |  [optional]



