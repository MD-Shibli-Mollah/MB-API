
# ErrorHeader

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**audit** | [**QueryHeaderAudit**](QueryHeaderAudit.md) |  |  [optional]
**status** | **String** | Status of the API(success/failed) |  [optional]



