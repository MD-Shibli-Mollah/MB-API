
# ErrorHeaderAudit

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**t24Time** | **Integer** | Time taken to response by Transact |  [optional]
**versionNumber** | **String** | The CURR.NO. of the record |  [optional]
**requestParseTime** | [**BigDecimal**](BigDecimal.md) | Time taken to parse the request by IRIS |  [optional]
**responseParseTime** | [**BigDecimal**](BigDecimal.md) | Time taken to parse the response by IRIS |  [optional]



