
# BusinessQueryErrorResponseBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**message** | **String** | The actual Transact error message for bad requests |  [optional]
**type** | **String** | The identifier of error type: Business |  [optional]
**code** | **String** | The identifier of the error message |  [optional]



