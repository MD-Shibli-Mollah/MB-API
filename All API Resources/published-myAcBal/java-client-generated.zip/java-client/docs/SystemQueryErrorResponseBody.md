
# SystemQueryErrorResponseBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**message** | **String** | The actual Transact error message caused by server |  [optional]
**type** | **String** | The identifier of error type: System |  [optional]
**code** | **String** | The identifier of the error message |  [optional]



