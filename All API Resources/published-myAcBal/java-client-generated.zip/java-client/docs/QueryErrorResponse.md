
# QueryErrorResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**error** | [**QueryErrorResponseBody**](QueryErrorResponseBody.md) |  |  [optional]
**header** | [**ErrorHeader**](ErrorHeader.md) |  |  [optional]



