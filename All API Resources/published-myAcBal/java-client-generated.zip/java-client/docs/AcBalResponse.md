
# AcBalResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**body** | [**AcBalResponseBody**](AcBalResponseBody.md) |  |  [optional]
**header** | [**QueryHeader**](QueryHeader.md) |  |  [optional]



