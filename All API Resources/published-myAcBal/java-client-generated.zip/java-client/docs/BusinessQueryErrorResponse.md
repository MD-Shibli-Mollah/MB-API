
# BusinessQueryErrorResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**error** | [**BusinessQueryErrorResponseBody**](BusinessQueryErrorResponseBody.md) |  |  [optional]
**header** | [**ErrorHeader**](ErrorHeader.md) |  |  [optional]



