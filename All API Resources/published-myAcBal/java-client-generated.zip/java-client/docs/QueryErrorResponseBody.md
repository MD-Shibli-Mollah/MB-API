
# QueryErrorResponseBody

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**message** | **String** | The actual Transact error message  |  [optional]
**type** | **String** | The identifier of error type:  |  [optional]
**code** | **String** | The identifier of the error message |  [optional]



