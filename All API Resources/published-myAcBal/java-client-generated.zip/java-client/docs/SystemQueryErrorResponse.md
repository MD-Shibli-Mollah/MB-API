
# SystemQueryErrorResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**error** | [**SystemQueryErrorResponseBody**](SystemQueryErrorResponseBody.md) |  |  [optional]
**header** | [**ErrorHeader**](ErrorHeader.md) |  |  [optional]



